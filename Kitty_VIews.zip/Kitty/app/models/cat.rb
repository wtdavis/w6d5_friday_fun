class Cat < ApplicationRecord

    CAT_COLORS = %w(black white orange brown grey)

    validates :birth_date, :color, :name, :sex, presence: true
    validates :color, inclusion: { in: CAT_COLORS }
    validates :sex, inclusion: { in: ["M", "F"]}
    validate :birth_date_cannot_be_future

    def birth_date_cannot_be_future
        if birth_date > Date.today
            errors.add(:birth_date, "Birth date can't be in the future")
        end
    end

    def age
        now = Time.current.to_date
        years = now.year - birth_date.year
        years -= 1 if now.yday < birth_date.yday
        return years
    end

end
